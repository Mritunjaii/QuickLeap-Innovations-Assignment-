module.exports = {
    checkAuth: require('./checkAuth'),
}