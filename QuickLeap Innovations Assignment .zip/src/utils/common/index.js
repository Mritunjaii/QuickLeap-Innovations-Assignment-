module.exports = {
    SuccessResponse: require("./success-response"),
    ErrorResponse: require("./error-response"),
};
