
module.exports = {
    AuthRepository: require('./AuthRepository'),
    PlanRepository: require('./planRepository'),
    SubscriptionRepository: require('./subscriptionRepository'),
}