
module.exports = {
    AuthController: require('./authController'),
    PlanController: require('./planController'),
    SubscriptionController: require('./subscriptionController'),
};