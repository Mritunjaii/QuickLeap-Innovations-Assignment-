
module.exports={
    AuthService: require('./authService'),
    PlanService: require('./planService'),
    SubscriptionService: require('./subscriptionService'),
}